# Basic Example

A simple [create-react-app](CRA-README.md) setup, showcasing one of the lastest React-Bootstrap components!
